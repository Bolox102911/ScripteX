return {
    Name = "AnticheatBypass", -- Addon Name (can't contain spaces)
	Title = "Anticheat Bypass", -- Name for the groupbox
	Description = "rig the anticheat (MUST RUN IN ELEVATOR OR LOBBY)", -- Can be empty if you don't want a description
    Game = "*", -- * means all games 

	Elements = {
		{
			Type = "Button",
			Name = "AnticheatBypass_Skibidi", -- Accessible by using Options[<AddonName>_<Name>], for this element you can access it by Options["FunItems_CrucfixEverything"]
			Arguments = {
				Text = 'Bypass Anticheat',
				Tooltip = 'Need to execute in elevator or lobby! (you can walk through the elevator door after execute)',

				Func = function()
                    --hi this is my skibidi anticheat bypass!! | made by ._bonus_.
					repeat 
                        task.wait()
                    until game:IsLoaded()
                    wait(2) 
                    --omg bro lsplash so funny
                    Library:Notify("Make sure to have no cutscene on and execute this in elevator or in the lobby!",2)
                    wait(1)
                    Library:Notify("You can just walk pass the elevator door after this message!",2)
                    wait(1)
                    Library:Notify("ESP might not work!",2)
                    if game:GetService("ReplicatedStorage").RemotesFolder:FindFirstChild("PreRunShop") then
                        game:GetService("ReplicatedStorage").RemotesFolder:FindFirstChild("PreRunShop"):Destroy() --yeah bro lsplash bs
                    end
                    if game:GetService("ReplicatedStorage").ClientModules.EntityModules:FindFirstChild("Void") then
                        game:GetService("ReplicatedStorage").ClientModules.EntityModules:FindFirstChild("Void"):Destroy()
                    end
                    if workspace.CurrentRooms["0"].StarterElevator:FindFirstChild("DoorHitbox") then
                        workspace.CurrentRooms["0"].StarterElevator:FindFirstChild("DoorHitbox"):Destroy()
                    end                
                    --this remove hiding prompt so you don't accidentally go inside hiding spot and stuck there forever
                    while true do
                        currentroom = tostring(game:GetService("ReplicatedStorage").GameData.LatestRoom.Value)
                        for _, v in pairs(workspace.CurrentRooms[currentroom]:GetDescendants()) do
                            if v.Name == "Wardrobe" or v.Name == "Locker_Large" or v.Name == "Bed" then
                                if v:FindFirstChild("HidePrompt") then
                                    v.HidePrompt:Destroy()
                                    end
                            end
                        end
                        task.wait(1)
                    end
				end
			},
        }
    }
}
