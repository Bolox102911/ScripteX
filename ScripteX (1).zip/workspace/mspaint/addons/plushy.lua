local Addon = {
	Name = "StupidAddon", -- Addon Name (can't contain spaces)
	Title = "lontong's addon", -- Name for the groupbox
	Description = "Stuff here", -- Can be empty if you don't want a description
	Game = "*", -- * means all games
	Elements = {
		{
		Type = "Button",
		Name = "test",
		Arguments = {
			Text = 'test',
			Tooltip = 'test',

			Func = function()
                print("test")
		}
	},
	{
		Type = "Toggle",
		Name = "FigGodMod", -- Acceg Opons[<AddonNe>_<], for this ment n ass it [glle"]
		Arguments = {
			Text = 'Avoid Figure',
			Tooltip = 'Avoid Figure (Works better in Door 50)',
		    Default = false,

			Callback = function(value)
                tval = value
                print("Making Figure weaker"..tostring(value))
                if tval == true then
                    getgenv().Library:Notify("Works better at door 50", 5)
                repeat
                    enabled = Options["StupidAddon_FigGodMod"]
                    print("Repeating")
                    if FigRoom == nil or not workspace.CurrentRooms:findFirstChild("50") or not workspace.CurrentRooms:findFirstChild("50").FigureSetup then
                 for i,v in pairs(workspace:GetDescendants()) do
                if v.Name == "FigureRig" and tval then
                    print("found")
                   FigRoom = v.Parent.Parent
                else
                --Nothing happens
                print("not found")
                end
            end
        end
                wait(0.25)
                if FigRoom ~= nil and workspace.CurrentRooms:findFirstChild("50") or workspace.CurrentRooms:findFirstChild("100")  then
                print(tostring(tval))
                 er =  (collision.Parent.HumanoidRootPart.Position - FigRoom.FigureSetup.FigureRig.Root.Position).Magnitude
            print(tostring(er))
                 if er <= 25 and tval and not FigNear then
                FigNear = true
            collision.Position -= Vector3.new(0, -24, 0) 
            elseif er >= 25 and FigNear and tval then
                FigNear = false
            collision.Position -= Vector3.new(0, 24, 0)
            end
            end
        
    until not tval
        print("Stopped")
else
print("shut up")
end
end
		}
	}
	}
} 

return Addon