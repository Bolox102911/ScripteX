local Options = getgenv().Linoria.Options
local Toggles = getgenv().Linoria.Toggles

local Addon = {
    Name = "UniversalRocketLauncher",  -- Addon Name
    Title = "Universal Rocket Launcher",  -- Title of the GroupBox
    Description = "A rocket launcher for use in any game.",  -- Addon Description
    Game = { "*" },  -- This makes the addon universal (available in all games)

    Elements = {
        {
            Type = "Button",  -- Button to spawn the rocket launcher
            Name = "EquipRocketLauncher",
            Arguments = {
                Text = 'Equip Rocket Launcher',  -- Button text
                Tooltip = 'Equip a rocket launcher to blow up objects.',  -- Tooltip description

                Func = function()  -- Function that equips the rocket launcher
                    local player = game.Players.LocalPlayer
                    local backpack = player:FindFirstChildOfClass("Backpack")

                    -- Check if the player already has the Rocket Launcher
                    if backpack:FindFirstChild("RocketLauncher") then
                        print("Rocket launcher already equipped.")
                        return
                    end

                    -- Create the rocket launcher tool
                    local tool = Instance.new("Tool")
                    tool.Name = "RocketLauncher"
                    tool.RequiresHandle = true
                    
                    -- Create a handle for the rocket launcher
                    local handle = Instance.new("Part")
                    handle.Name = "Handle"
                    handle.Size = Vector3.new(1, 1, 2)
                    handle.BrickColor = BrickColor.new("Bright red")
                    handle.CanCollide = false
                    handle.Parent = tool
                    
                    -- Add sound effect (classic Roblox rocket launcher sound)
                    local sound = Instance.new("Sound", handle)
                    sound.SoundId = "rbxassetid://133121747"  -- Old Roblox rocket launcher sound
                    sound.Volume = 1
                    
                    -- Parent the rocket launcher tool to the player's backpack
                    tool.Parent = backpack

                    -- Tool behavior (fires rocket when activated)
                    tool.Activated:Connect(function()
                        print("Rocket launcher fired!")
                        
                        -- Play sound
                        sound:Play()

                        -- Create rocket projectile
                        local rocket = Instance.new("Part")
                        rocket.Size = Vector3.new(1, 1, 2)
                        rocket.BrickColor = BrickColor.new("Bright red")
                        rocket.CanCollide = false
                        rocket.CFrame = tool.Handle.CFrame
                        rocket.Parent = workspace

                        -- Apply velocity to rocket
                        local bodyVelocity = Instance.new("BodyVelocity")
                        bodyVelocity.Velocity = tool.Handle.CFrame.lookVector * 100  -- Rocket speed
                        bodyVelocity.Parent = rocket

                        -- Explosion and destruction logic
                        rocket.Touched:Connect(function(hit)
                            if hit:IsA("Part") then
                                print("Rocket hit an object!")
                                local explosion = Instance.new("Explosion")
                                explosion.Position = rocket.Position
                                explosion.BlastRadius = 10
                                explosion.BlastPressure = 50000
                                explosion.Parent = workspace
                                rocket:Destroy()
                            end
                        end)

                        -- Auto-destroy rocket after 5 seconds
                        game.Debris:AddItem(rocket, 5)
                    end)
                end
            },

            Elements = {  -- Optional inner elements
                {
                    Type = "Button",
                    Name = "RemoveRocketLauncher",
                    Arguments = {
                        Text = 'Remove Rocket Launcher',
                        Tooltip = 'Removes the rocket launcher from your inventory.',

                        Func = function()
                            local player = game.Players.LocalPlayer
                            local backpack = player:FindFirstChildOfClass("Backpack")
                            local rocketLauncher = backpack:FindFirstChild("RocketLauncher")

                            if rocketLauncher then
                                print("Removing rocket launcher...")
                                rocketLauncher:Destroy()
                            else
                                print("No rocket launcher found.")
                            end
                        end
                    }
                }
            }
        },

        {
            Type = "Divider"
        },

        {
            Type = "Toggle",  -- Toggle for enabling/disabling rocket explosion sound
            Name = "DisableSound",
            Arguments = {
                Text = 'Disable Explosion Sound',
                Tooltip = 'Turn off the rocket explosion sound.',

                Enabled = false,  -- Initial state
                Callback = function(value)
                    _G.disable_sound = value
                end
            }
        }
    }
}

return Addon