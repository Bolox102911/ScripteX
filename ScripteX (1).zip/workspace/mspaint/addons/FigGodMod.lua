ThatcherTakenOver = 0
collision = game.Players.LocalPlayer.Character.Collision
collision.Position -= Vector3.new(0, 0, 0)
print("test")
FigNear = false
local FigRoom = nil
PartCountB = 0
PartCount = 0
---Thatcher Script
local Options = getgenv().Linoria.Options;
local Toggles = getgenv().Linoria.Toggles;
--This sack of shit was brought to you by lontong, Enjoy this messy, poorly-coded and disorganized piece of shit (maybe) that i spent like 3 hours debugging and only finding out a simple problem which caused the entire script to break
local tval = false
function Tthatcher()
    for i,v in pairs(workspace:GetDescendants()) do
        if v:IsA("Texture") or v:IsA("Decal") then
            chance = math.random(1,2)
            if chance == 1 and v.Texture ~= "rbxassetid://176501501" then
                ThatcherTakenOver += 1
                v.Texture = "rbxassetid://176501501"
            end
        end
        if v:IsA("BasePart") and not v:findFirstChild("Texture") then
            chance = math.random(1,5)
            if chance == 1 and v.Parent.Parent ~= game.Players.LocalPlayer.Character then
            PartCountB += 1
            ThatcherTakenOver += 1
            newTex = Instance.new("Texture")
            newTex.Parent = v
            newTex.Texture = "rbxassetid://176501501"
            newTex.Face = "Left"
            newTex2 = newTex:Clone()
            newTex2.Parent = v
            newTex2.Face = "Right"
            newTex5 = newTex:Clone()
            newTex5.Parent = v
            newTex5.Face = "Top"
            newTex3 = newTex:Clone()
            newTex3.Parent = v
            newTex3.Face = "Bottom"
            newTex4 = newTex:Clone()
            newTex4.Parent = v
            newTex4.Face = "Front"      
            newTex6 = newTex:Clone()
            newTex6.Parent = v
            newTex6.Face = "Back"  
            
            end         
        end 
        if v:IsA("BasePart") then
            PartCount += 1  
     end     
    end
    game.TextChatService.TextChannels.RBXGeneral:DisplaySystemMessage("Mergaret Thatcher has taken over "..ThatcherTakenOver.." parts of the world. ("..(100 -((PartCountB/PartCount) * 100)).."%)") 
PartCount = 0
PartCountB = 0
    ThatcherTakenOver = 0
end   
--ROOM CHECK




local Addon = {
	Name = "StupidAddon", -- Addon Name (can't contain spaces)
	Title = "Bolox addon", -- Name for the groupbox
	Description = "Addon by Bolox", -- Can be empty if you don't want a description
	Game = "*", -- * means all games
	Elements = {
		{
		Type = "Button",
		Name = "MargaretThatcher",
		Arguments = {
			Text = 'Margaret Thatcher',
			Tooltip = 'Takes over parts of the world',

			Func = function()
                Tthatcher()
			end
		}
	},

    {
        Type = "Divider"
    },

	{
		Type = "Toggle",
		Name = "FigGodMod", -- Acceg Opons[<AddonNe>_<], for this ment n ass it [glle"]
		Arguments = {
			Text = 'Avoid Figure',
			Tooltip = 'works like avoid ambush or rush (Works better in Door 50)',
		    Default = false,

			Callback = function(value)
                tval = value
                print("Making Figure weaker"..tostring(value))
                if tval == true then
                    getgenv().Library:Notify("Successfully made Figure weaker", 5)
                repeat
                    enabled = Options["StupidAddon_FigGodMod"]
                    print("Repeating")
                    if FigRoom == nil or not workspace.CurrentRooms:findFirstChild("50") or not workspace.CurrentRooms:findFirstChild("50").FigureSetup then
                 for i,v in pairs(workspace:GetDescendants()) do
                if v.Name == "FigureRig" and tval then
                    print("found")
                   FigRoom = v.Parent.Parent
                else
                --Nothing happens
                print("not found")
                end
            end
        end
                wait(0.25)
                if FigRoom ~= nil and workspace.CurrentRooms:findFirstChild("50") or workspace.CurrentRooms:findFirstChild("100")  then
                print(tostring(tval))
                 er =  (collision.Parent.HumanoidRootPart.Position - FigRoom.FigureSetup.FigureRig.Root.Position).Magnitude
            print(tostring(er))
                 if er <= 25 and tval and not FigNear then
                FigNear = true
            collision.Position -= Vector3.new(0, -24, 0) 
            elseif er >= 25 and FigNear and tval then
                FigNear = false
            collision.Position -= Vector3.new(0, 24, 0)
            end
            end
        
    until not tval
        print("Stopped")
else
print("shut up")
end
end
		}
	}
	}
} 

return Addon