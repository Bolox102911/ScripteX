local Options = getgenv().Linoria.Options;
local Toggles = getgenv().Linoria.Toggles;

local Addon = {
    Name = "TplayAddon",
    Title = "Tplay",
    Game = {
        "doors/doors"
    },

    Elements = {
        {
            Type = "Toggle",
            Name = "Stun",
            Arguments = {
                Text = 'Stun',
                Tooltip = 'Enable to Stun',
                Enabled = false,

                Callback = function(value)
                    
                    local cfcfcf = game.Players.LocalPlayer
                    
                    if value then
                        cfcfcf.Character:SetAttribute('Stunned', true)
                    else
                        cfcfcf.Character:SetAttribute('Stunned', false)
                    end
                end
            }
        },

        {
            Type = "Toggle",
            Name = "NoAnimation",
            Arguments = {
                Text = 'No Animation',
                Tooltip = 'Disables Animation',
                Enabled = false,

                Callback = function(value)
                    local addonf0 = game.Players.LocalPlayer.PlayerGui
                    local addonf1 = addonf0:WaitForChild("MainUI")
                    local addonf2 = addonf1:WaitForChild("Initiator"):WaitForChild("Main_Game")
                    local addonf3 = if ExecutorSupport["require"] then require(addonf2) else nil
                    
                    if value then
                        addonf3.disableMovement = true
                    else
                        addonf3.disableMovement = false
                    end
                end
            }
        },

        {
            Type = "Toggle",
            Name = "NoWardrobeVignette",
            Arguments = {
                Text = 'No Wardrobe Vignette',
                Tooltip = 'Disables Vignette when you hiding in Wardrobe',
                Enabled = false,

                Callback = function(value)
                    local vignette = game:GetService("Players").LocalPlayer.PlayerGui.MainUI.MainFrame.HideVignette

                    if value then
                        vignette.Size = UDim2.new(0, 0, 0, 0)
                    else
                        vignette.Size = UDim2.new(1, 0, 1, 0)
                    end
                end
            }
        },

        {
            Type = "Toggle",
            Name = "ThinkingAnimation",
            Arguments = {
                Text = 'Thinking Animation',
                Tooltip = 'Enables random thinking animation (FE)',
                Enabled = false,

                Callback = function(value)
                    local backout = game:GetService("Players").LocalPlayer.PlayerGui.MainUI.MinigameBackout

                    if value then
                        backout.Size = UDim2.new(0, 0, 0, 0)
                        backout.Visible = true
                    else
                        backout.Size = UDim2.new(0.1, 50, 0.1, 50)
                        backout.Visible = false
                    end
                end
            }
        },

        {
            Type = "Toggle",
            Name = "NoDarkSound",
            Arguments = {
                Text = 'No Dark Ambience',
                Tooltip = 'Remove Dark Ambience Sound',
                Enabled = false,

                Callback = function(value)
                    if value then
                        workspace.Ambience_Dark.Volume = 0
                    else
                        workspace.Ambience_Dark.Volume = 0.6
                    end
                end
            }
        }
    }
}

return Addon;