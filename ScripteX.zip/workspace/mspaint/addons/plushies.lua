local Options = getgenv().Linoria.Options;
local Toggles = getgenv().Linoria.Toggles;

local player = game.Players.LocalPlayer
local character = player.Character or player.CharacterAdded:Wait()
local humanoid = character:WaitForChild("Humanoid")
local anim = humanoid:LoadAnimation(game:GetObjects("rbxassetid://13613269677")[1].A.Hold)

return {
    Name = "plushies", 
    Title = "Plushies",
    Description = "Random Plushies ingame :D",
    Game = "*", 
    Elements = {
        {
            Type = "Input",
            Name = "CustomToolInput",
            Arguments = {
                Text = "Custom Plush Id:",
                Tooltip = "U can load a custom plush/tool with the id",
            },
        },
        {
            Type = "Button",
            Name = "LoadCustomTool",
            Arguments = {
                Text = "Load Custom Plush",
                Tooltip = "Load the plush/tool with the id above",
                Func = function()
                    local customPlushId = Options["plushies_CustomToolInput"].Value
                    local customPlush = game:GetObjects("rbxassetid://".. customPlushId)[1]
                    customPlush.Parent = player.Backpack

                    customPlush.Equipped:Connect(function()
                        anim:Play()
                    end)

                    customPlush.Unequipped:Connect(function()
                        anim:Stop()
                    end)
                end
            },
        },

        {
            Type = "Divider"
        },

        {
            Type = "Label",
            Name = "PlushiesLabel",
            Arguments = {
                "Plushies"
            },
        },

        {
            Type = "Button",
            Name = "Seek",
            Arguments = {
                Text = "Seek Plushie",
                Tooltip = "U get a Seek plushie in ur inventory",
                Func = function()
                    local plush = game:GetObjects("rbxassetid://13613269677")[1]
                    plush.Parent = player.Backpack

                    plush.Equipped:Connect(function()
                        anim:Play()
                    end)

                    plush.Unequipped:Connect(function()
                        anim:Stop()
                    end)
                end
            },
        },

        {
            Type = "Button",
            Name = "DrunkA60",
            Arguments = {
                Text = "A60 on crack",
                Tooltip = "U get a weird ass A60 in ur inventory",
                Func = function()
                    local plush = game:GetObjects("rbxassetid://12044266502")[1]
                    plush.Parent = player.Backpack

                    plush.Equipped:Connect(function()
                        anim:Play()
                    end)

                    plush.Unequipped:Connect(function()
                        anim:Stop()
                    end)
                end
            },
        },

        {
            Type = "Button",
            Name = "Silence",
            Arguments = {
                Text = "Silence Plushie",
                Tooltip = "U get a Silence plushie in ur inventory",
                Func = function()
                    local plush = game:GetObjects("rbxassetid://17170996845")[1]
                    plush.Parent = player.Backpack

                    plush.Equipped:Connect(function()
                        anim:Play()
                    end)

                    plush.Unequipped:Connect(function()
                        anim:Stop()
                    end)
                end
            },
        },

        {
            Type = "Button",
            Name = "CircleDread",
            Arguments = {
                Text = "Circle Dread Plushie",
                Tooltip = "U get a Dread plushie in ur inventory",
                Func = function()
                    local plush = game:GetObjects("rbxassetid://13071801863")[1]
                    plush.Parent = player.Backpack

                    plush.Equipped:Connect(function()
                        anim:Play()
                    end)

                    plush.Unequipped:Connect(function()
                        anim:Stop()
                    end)
                end
            },
        },

        {
            Type = "Button",
            Name = "WindowGuy",
            Arguments = {
                Text = "Window Guy Plushie",
                Tooltip = "U get the Window guy plushie in ur inventory",
                Func = function()
                    local plush = game:GetObjects("rbxassetid://17161144351")[1]
                    plush.Parent = player.Backpack

                    plush.Equipped:Connect(function()
                        anim:Play()
                    end)

                    plush.Unequipped:Connect(function()
                        anim:Stop()
                    end)
                end
            },
        },

        {
            Type = "Button",
            Name = "GoldCoin",
            Arguments = {
                Text = "Gold Coin Plushie",
                Tooltip = "U get a Gold coin plushie in ur inventory",
                Func = function()
                    local plush = game:GetObjects("rbxassetid://17171193416")[1]
                    plush.Parent = player.Backpack

                    plush.Equipped:Connect(function()
                        anim:Play()
                    end)

                    plush.Unequipped:Connect(function()
                        anim:Stop()
                    end)
                end
            },
        },

        {
            Type = "Button",
            Name = "Eyes",
            Arguments = {
                Text = "Eyes Plushie",
                Tooltip = "U get an eyes plushie in ur inventory",
                Func = function()
                    local plush = game:GetObjects("rbxassetid://13138650442")[1]
                    plush.Parent = player.Backpack

                    plush.Equipped:Connect(function()
                        anim:Play()
                    end)

                    plush.Unequipped:Connect(function()
                        anim:Stop()
                    end)
                end
            },
        },
        
        {
            Type = "Button",
            Name = "Ambush",
            Arguments = {
                Text = "Ambush Plushie",
                Tooltip = "U get an Ambush plushie in ur inventory",
                Func = function()
                    local plush = game:GetObjects("rbxassetid://12412045204")[1]
                    plush.Parent = player.Backpack

                    plush.Equipped:Connect(function()
                        anim:Play()
                    end)

                    plush.Unequipped:Connect(function()
                        anim:Stop()
                    end)
                end
            },
        },
        
        {
            Type = "Button",
            Name = "GuidingLight",
            Arguments = {
                Text = "Ugly Guiding light Plushie",
                Tooltip = "U get a Guiding light plushie in ur inventory",
                Func = function()
                    local plush = game:GetObjects("rbxassetid://17161394126")[1]
                    plush.Parent = player.Backpack

                    plush.Equipped:Connect(function()
                        anim:Play()
                    end)

                    plush.Unequipped:Connect(function()
                        anim:Stop()
                    end)
                end
            },
        },
        
        {
            Type = "Button",
            Name = "Rush",
            Arguments = {
                Text = "Rush Plush (haha rhymes)",
                Tooltip = "U get a rush plush in ur inventory",
                Func = function()
                    local plush = game:GetObjects("rbxassetid://12411542112")[1]
                    plush.Parent = player.Backpack

                    plush.Equipped:Connect(function()
                        anim:Play()
                    end)

                    plush.Unequipped:Connect(function()
                        anim:Stop()
                    end)
                end
            },
        },
        
        {
            Type = "Button",
            Name = "Jack",
            Arguments = {
                Text = "Jack Plushie",
                Tooltip = "U get a Jack plushie in ur inventory",
                Func = function()
                    local plush = game:GetObjects("rbxassetid://13134833039")[1]
                    plush.Parent = player.Backpack

                    plush.Equipped:Connect(function()
                        anim:Play()
                    end)

                    plush.Unequipped:Connect(function()
                        anim:Stop()
                    end)
                end
            },
        },
        
        {
            Type = "Button",
            Name = "KawaiiScreech",
            Arguments = {
                Text = "Kawaii screech plushie (kill me)",
                Tooltip = "U get a Screech plushie in ur inventory",
                Func = function()
                    local plush = game:GetObjects("rbxassetid://12116883681")[1]
                    plush.Parent = player.Backpack

                    plush.Equipped:Connect(function()
                        anim:Play()
                    end)

                    plush.Unequipped:Connect(function()
                        anim:Stop()
                    end)
                end
            },
        },

        {
            Type = "Button",
            Name = "FryPc",
            Arguments = {
                Text = "Fry pc plush :D",
                Tooltip = "U get a i dont even know plushie in ur inventory",
                Func = function()
                    local plush = game:GetObjects("rbxassetid://12338008713")[1]
                    plush.Parent = player.Backpack

                    plush.Equipped:Connect(function()
                        anim:Play()
                    end)

                    plush.Unequipped:Connect(function()
                        anim:Stop()
                    end)
                end
            },
        },

        {
            Type = "Button",
            Name = "BuggyDread",
            Arguments = {
                Text = "Buggy Dread Plushie (Dont use)",
                Tooltip = "U get a Dread plushie in ur inventory",
                Func = function()
                    local plush = game:GetObjects("rbxassetid://17160696892")[1]
                    plush.Parent = player.Backpack

                    plush.Equipped:Connect(function()
                        anim:Play()
                    end)

                    plush.Unequipped:Connect(function()
                        anim:Stop()
                    end)
                end
            },
        },
    }
}