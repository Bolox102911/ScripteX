return {
    Name = "JonklerV4Fanmade",
	Title = "Jonkler V4",
    Game = "*",
	Elements = {
		{
			Type = "Button",
			Name = "JonkButton",
			Arguments = {
				Text = 'Summon Jonklerv4.exe',
				Tooltip = 'Someone is waiting for you.',
				Func = function()
                    
                    if not _G.JonklerLoaded then
                        _G.JonklerLoaded = true
					    local lplayer = game:GetService("Players").LocalPlayer
                        local char = lplayer.Character
                        local rppos
                        local MCC = game:GetService("Lighting"):WaitForChild("MainColorCorrection")
                        local music = Instance.new("Sound")
                        local function SpawnJonkler()
                            MCC.TintColor = Color3.new(1, 0.25, 0.25)
                            rppos = char.HumanoidRootPart.Position
                            local MP = Instance.new("Part")
                            _G.MP = MP
                            MP.Parent = workspace
                            MP.Name = "Main"
                            MP.Transparency = 1
                            MP.Size = Vector3.new(6.46, 6.23, 6.36)
                            MP.Position = rppos + Vector3.new(900, 0, 600)
                            MP.CanCollide = false
                            MP.Anchored = true
                            local MPGUI = Instance.new("BillboardGui")
                            MPGUI.Parent = MP
                            MPGUI.AlwaysOnTop = true
                            MPGUI.Size = UDim2.new(10.5,0,10.5,0)
                            local JIMG = Instance.new("ImageLabel")
                            JIMG.Size = UDim2.new(1,0,1,0)
                            JIMG.Image = "http://www.roblox.com/asset/?id=117277806496008"
                            JIMG.BorderSizePixel = 0
                            JIMG.Parent = MPGUI
                            local FS = Instance.new("Sound")
                            FS.Name = "Footsteps"
                            FS.Parent = MP
                            FS.SoundId = "rbxassetid://138085144"
                            FS.RollOffMaxDistance = 2000
                            FS.RollOffMinDistance = 5
                            FS.Looped = true
                            FS.PlaybackSpeed = 1
                            FS.Volume = 1.25
                            local FSD = Instance.new("DistortionSoundEffect")
                            FSD.Parent = FS
                            FSD.Level = 0.97
                            local FSE = Instance.new("EqualizerSoundEffect")
                            FSE.Parent = FS
                            FSE.HighGain = 1
                            FSE.LowGain = -26
                            FSE.MidGain = -0.8
                            local FSF = Instance.new("FlangeSoundEffect")
                            FSF.Parent = FS
                            FSF.Depth = 1
                            FSF.Mix = 1
                            FSF.Rate = 0.2
                            local FS2 = Instance.new("Sound")
                            FS2.Name = "PlaySound"
                            FS2.Parent = MP
                            FS2.SoundId = "rbxassetid://11037660439"
                            FS2.RollOffMaxDistance = 2000
                            FS2.RollOffMinDistance = 5
                            FS2.Looped = true
                            FS2.PlaybackSpeed = 0.6
                            FS2.Volume = 3
                            local FS2D = Instance.new("DistortionSoundEffect")
                            FS2D.Parent = FS2
                            FS2D.Level = 0.86
                            FS2D.Priority = 3
                            local FS2E = Instance.new("EqualizerSoundEffect")
                            FS2E.Parent = FS2
                            FS2E.HighGain = -66.5
                            FS2E.LowGain = 6.4
                            FS2E.MidGain = -80
                            FS.Playing = true
                            FS2.Playing = true
                        end
					    local function musicSync()
					        while true do
						        task.wait(2.2)
						        music.TimePosition = 5
						        task.wait(1.8)
						        music.TimePosition = 0
					        end
					    end
                        local function JonklerAttackRecover()
                            local char = game:GetService("Players").LocalPlayer.Character
                            local WLC = true
                            MCC.TintColor = Color3.new(0.6, 0.83, 0.6)
                            while WLC do
                                _G.blur.Size = _G.blur.Size - 0.1
                                if _G.blur.Size == 0 or _G.blur.Size < 0 then
                                    WLC = false
                                    char:SetAttribute("Stunned", false)
                                end
                                task.wait(.025)
                            end
                        end
                        local function JonklerChaseEnd()
                            _G.MP.Parent = nil
                            char:SetAttribute("Stunned", true)
                            _G.blur = Instance.new("BlurEffect")
                            _G.blur.Parent = game:GetService("Lighting")
                            _G.blur.Size = 48
                            task.spawn(JonklerAttackRecover)
                            char.Humanoid:TakeDamage(30)
                        	music.Parent = game:GetService("SoundService")
                        	music.SoundId = "rbxassetid://138085144"
                            music.Looped = true
                        	music.Volume = 1.25
                            music.TimePosition = 0
                            music.PlaybackSpeed = 0.9
                        	music.Playing = true
                            task.spawn(musicSync)
                            for count = 0, 25, 1 do
                                count += 1
                                task.wait(.05)
                                local IMAGE_ID = "http://www.roblox.com/asset/?id=117277806496008"
                                local IMAGE_RES = UDim2.fromOffset(175, 175)
                                local MOVE_SPEED = 1500
                                local DirX, DirY = 1, 1
                                local function CreateWithProperties(ClassName, Properties)
                                    local Object = Instance.new(ClassName)
                                    for Name, Value in Properties do
                                        Object[Name] = Value
                                    end
                                    return Object
                                end
                                local UI = CreateWithProperties("ScreenGui", {
                                    ResetOnSpawn = false,
                                    IgnoreGuiInset = true,
                                    DisplayOrder = 999,
                                    Parent = game.CoreGui
                                })
                                local Image: ImageLabel = CreateWithProperties("ImageLabel", {
                                    Size = IMAGE_RES,
                                    BorderSizePixel = 0,
                                    BackgroundTransparency = 1,
                                    Image = IMAGE_ID,
                                    AnchorPoint = Vector2.new(0.5, 0.5),
                                    Parent = UI
                                })
                                local function GetDirection(Axis)
                                    return Image.Position[Axis].Offset + Image.Size[Axis].Offset / 2 > workspace.CurrentCamera.ViewportSize[Axis] and -1
                                        or Image.Position[Axis].Offset - Image.Size[Axis].Offset / 2 < 0 and 1
                                end
                                game:GetService("RunService").Heartbeat:Connect(function(Delta)
                                    DirX = GetDirection("X") or DirX
                                    DirY = GetDirection("Y") or DirY
                                    local MoveAmount = MOVE_SPEED * Delta
                                    Image.Position += UDim2.fromOffset(MoveAmount * DirX, MoveAmount * DirY)
                                end)
                            end
                            local decalTexture = "http://www.roblox.com/asset/?id=117277806496008"
                        	for i,part in ipairs(workspace:GetDescendants()) do
                        		if part:IsA("BasePart") and not part:FindFirstAncestorWhichIsA("Model"):FindFirstChildWhichIsA("Humanoid") then
                        			for i2,face in ipairs(Enum.NormalId:GetEnumItems()) do
                        				local decal = Instance.new("Decal")
                        				decal.Parent = part
                        				decal.Face = face
                        				decal.Texture = decalTexture
                        			end
                        		end
                        	end
                        	workspace.CurrentRooms.ChildAdded:Connect(function(room)
                        	    for i,part in ipairs(workspace:GetDescendants()) do
                        		    if part:IsA("BasePart") and not part:FindFirstAncestorWhichIsA("Model"):FindFirstChildWhichIsA("Humanoid") then
                        			    for i2,face in ipairs(Enum.NormalId:GetEnumItems()) do
                        			    	local decal = Instance.new("Decal")
                        			    	decal.Parent = part
                        			    	decal.Face = face
                        			    	decal.Texture = decalTexture
                        			    end
                        		    end
                        	    end
                            end)
                            wait(1)
                            repeat char.Humanoid:TakeDamage(-1) wait(0.25) until char.Humanoid.Health == 100
                        end
                        local function JonklerChaseInit()
                            local object = _G.MP
                            local player = game.Players.LocalPlayer
                            local speed = 55
                            local chase = true
                            while chase do
                        	    local playerPos = player.Character.HumanoidRootPart.Position
                        	    local objectPos = object.Position
                        	    local direction = (playerPos - objectPos).Unit
                        	    local distance = (playerPos - objectPos).Magnitude
                        	    if distance > 1 then
                        	    	object.CFrame = object.CFrame + direction * speed * math.min(distance, 1/60)
                        	    else
                                    chase = false
                                    task.spawn(JonklerChaseEnd)
                                end
                                task.wait()
                            end
                        end
                        local function ScriptStart()
                            task.spawn(SpawnJonkler)
                            task.wait(1)
                            task.spawn(JonklerChaseInit)
                        end
                        task.spawn(ScriptStart)
                    end
				end
			},
        }
    }
}