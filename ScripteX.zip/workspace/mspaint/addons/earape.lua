return {
   Name = "LobotomyMode",
   Title = "Lobotomy Mode",
   Game = "*",
   Elements = {
       {
           Type = "Button",
           Name = "startlobotomy",
           Arguments = {
               Text = 'Lobotomy Button',
               Tooltip = 'hmm..',
               Func = function()
                   if not _G.LobotomyLoaded then
                       _G.LobotomyLoaded = true
                       local cce = Instance.new("ColorCorrectionEffect")
                       local ss = game:GetService("SoundService")
                       local ws = workspace
                       local rs = game:GetService("ReplicatedStorage")
                       local caption = rs.RemotesFolder.Caption
                       local function soundsvolumetomax()
                           while true do
                               task.wait(0.03)
                               for e, sounds in ipairs(ws:GetDescendants()) do
                                   if sounds.ClassName == "Sound" then
                                       sounds.Volume = 10
                                   end
                               end
                           end
                       end
                       local function soundgroupsvolumetomax()
                           while true do
                               task.wait(0.03)
                               for e, soundgroups in ipairs(ss:GetDescendants()) do
                                   if soundgroups.ClassName == "SoundGroup" then
                                       soundgroups.Volume = 10
                                   end
                               end
                           end
                       end
                       local function hellforepileptic()
                           while true do
                               cce.TintColor = Color3.new(math.random(0, 1), math.random(0, 1), math.random(0, 1))
                               cce.Contrast = math.random(0, 5)
                               cce.Saturation = math.random(0, 1)
                               task.wait(0.03)
                           end
                       end
                       local function disablecaptions()
                           task.wait(3)
                           while true do
                               if caption.OnClientEvent then
                                   firesignal(caption.OnClientEvent, "-.-. .- .--. - .. --- -. ...  .... .- ...  -... . . -.  -.. .. ... .- -... .-.. . -..")
                               end
                               task.wait()
                           end
                       end
                       firesignal(caption.OnClientEvent, "!!!EPILEPSY AND LOUD SOUNDS WARNING!!!")
                       task.wait(3)
                       firesignal(caption.OnClientEvent, "Lobotomy mode start working in:")
                       task.wait(2)
                       firesignal(caption.OnClientEvent, "3")
                       task.wait(1)
                       firesignal(caption.OnClientEvent, "2")
                       task.wait(1)
                       firesignal(caption.OnClientEvent, "1")
                       task.wait(1)
                       firesignal(caption.OnClientEvent, "L0#ot0My #0de haS b3_n AcT%vat@")
                       cce.Parent = ws.Camera
                       task.spawn(hellforepileptic)
                       task.spawn(soundsvolumetomax)
                       task.spawn(soundgroupsvolumetomax)
                       task.spawn(disablecaptions)
                   end
               end
           },
       }
   }
}