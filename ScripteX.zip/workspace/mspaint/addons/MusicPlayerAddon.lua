local Options = getgenv().Linoria.Options
local Toggles = getgenv().Linoria.Toggles

local Addon = {
    Name = "MusicPlayerAddon",  -- Addon Name
    Title = "Music Player",      -- Title of the GroupBox
    Description = "Listen to your favorite tunes!",
    Game = {
        "doors/doors",            -- Targeted games
        "doors/lobby"
    },

    Elements = {
        {
            Type = "Toggle",  -- Toggle for built-in song
            Name = "ToggleRainingTacos",
            Arguments = {
                Text = 'Play/Stop "It's Raining Tacos"',
                Tooltip = 'Click to play or stop the song.',
                
                Callback = function(value)
                    local player = game.Players.LocalPlayer
                    local sounds = game:GetService("SoundService")

                    -- Create a BoolValue to track if the song is playing
                    if not player:FindFirstChild("songplaying") then
                        local songplay = Instance.new("BoolValue")
                        songplay.Name = "songplaying"
                        songplay.Parent = player
                    end
                    
                    -- Check for existing sound instance
                    local tacosSound = sounds:FindFirstChild("RainingTacos")
                    if not tacosSound then
                        tacosSound = Instance.new("Sound")
                        tacosSound.Name = "RainingTacos"
                        tacosSound.SoundId = "rbxassetid://142295308"  -- ID for "It's Raining Tacos"
                        tacosSound.Looped = true
                        tacosSound.Volume = _G.SongVolume or 1
                        tacosSound.Parent = sounds
                    end

                    -- Play or stop the song based on the toggle value
                    if value then
                        tacosSound:Play()
                        player.songplaying.Value = true
                        print('"It's Raining Tacos" is now playing!')
                    else
                        tacosSound:Stop()
                        player.songplaying.Value = false
                        print('"It's Raining Tacos" has been stopped.')
                    end
                end
            }
        },

        {
            Type = "Input",  -- Input for custom song ID
            Name = "CustomSongId",
            Arguments = {
                Default = '',
                Numeric = true,
                Finished = true,
                ClearTextOnFocus = true,

                Text = 'Enter Custom Song ID',
                Tooltip = 'Input a valid Roblox sound ID',

                Placeholder = 'Enter a sound ID here',

                Callback = function(value)
                    _G.customSongId = tonumber(value)
                    print("Custom song ID set to: " .. tostring(_G.customSongId))
                end
            }
        },

        {
            Type = "Button",  -- Button to play the custom song
            Name = "PlayCustomSong",
            Arguments = {
                Text = 'Play Custom Song',
                Tooltip = 'Plays the song using the provided ID.',
                
                Func = function()
                    local sounds = game:GetService("SoundService")
                    local customSongSound = sounds:FindFirstChild("CustomSong")
                    
                    if not customSongSound then
                        customSongSound = Instance.new("Sound")
                        customSongSound.Name = "CustomSong"
                        customSongSound.Looped = true
                        customSongSound.Volume = _G.SongVolume or 1
                        customSongSound.Parent = sounds
                    end

                    -- Check for a valid custom song ID
                    if _G.customSongId then
                        customSongSound.SoundId = "rbxassetid://" .. tostring(_G.customSongId)
                        customSongSound:Play()
                        print("Playing custom song with ID: " .. tostring(_G.customSongId))
                    else
                        print("Please enter a valid song ID first.")
                    end
                end
            }
        },

        {
            Type = "Button",  -- Button to stop the custom song
            Name = "StopCustomSong",
            Arguments = {
                Text = 'Stop Custom Song',
                Tooltip = 'Stops the currently playing custom song.',
                
                Func = function()
                    local sounds = game:GetService("SoundService")
                    local customSongSound = sounds:FindFirstChild("CustomSong")
                    
                    if customSongSound and customSongSound.IsPlaying then
                        customSongSound:Stop()
                        print("Custom song has been stopped.")
                    else
                        print("No custom song is currently playing.")
                    end
                end
            }
        },

        {
            Type = "Slider",  -- Slider for volume control
            Name = "VolumeOfSong",
            Arguments = {
                Text = 'Volume',
                Tooltip = 'Adjust the volume for the songs.',
                Default = 1,
                Max = 2,
                Min = 0,
                Rounding = 1,

                Callback = function(value)
                    _G.SongVolume = tonumber(value)
                    local sounds = game:GetService("SoundService")

                    -- Update the volume of currently playing sounds
                    local tacosSound = sounds:FindFirstChild("RainingTacos")
                    if tacosSound then
                        tacosSound.Volume = _G.SongVolume
                    end
                    
                    local customSongSound = sounds:FindFirstChild("CustomSong")
                    if customSongSound then
                        customSongSound.Volume = _G.SongVolume
                    end
                    print("Volume set to: " .. tostring(_G.SongVolume))
                end
            }
        }
    }
}

return Addon
