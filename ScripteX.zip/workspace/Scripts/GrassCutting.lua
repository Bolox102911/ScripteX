-- grass cutting script made by us <3
loadstring(game:HttpGet("https://raw.githubusercontent.com/Bolox102911/GrassCutting/refs/heads/main/GrassCuttingScript"))()